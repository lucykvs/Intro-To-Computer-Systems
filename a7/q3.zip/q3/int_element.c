#include "int_element.h"

/* TODO: Implement all public int_element functions, including element interface functions.

You may add your own private functions here too. */
